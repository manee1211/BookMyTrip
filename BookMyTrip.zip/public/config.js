config={
    images:[
        "http://127.0.0.1:7100/images/slide8.jpg",
        "http://127.0.0.1:7100/images/slide9.jpg",
        "http://127.0.0.1:7100/images/slide10.jpg",
        "http://127.0.0.1:7100/images/slide11.jpg",
    ],
    appContextPath:"",
    backendURL:"http://127.0.0.1:1211/",
    alertConfig:{
        alertAutoHideDuration:3000,
        vertical: "bottom",
        horizontal: "center"
    }
}