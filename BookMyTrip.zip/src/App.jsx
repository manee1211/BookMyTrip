import { HashRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import HomePage from "./components/homePage/HomePage";
import PackageList from "./components/packageList/PackageList";
import ContactUs from "./components/contactUs/ContactUs";
import LandingPage from "./components/landingPage/LandingPage";
import SignUp from "./components/signup/SignUp";
import SignIn from "./components/signin/SignIn";
import PackageDetails from "./components/packageDetails/PackageDetails";

function App() {
  return (
    <>
      <HashRouter>
        <Routes>
          <Route path="/" element={<LandingPage></LandingPage>}>
            <Route
              path="/"
              element={<HomePage></HomePage>}
            ></Route>
            <Route
              path="/packages"
              element={<PackageList></PackageList>}
            ></Route>
            <Route path="/contact" element={<ContactUs></ContactUs>}></Route>
            <Route path="/signin" element={<SignIn></SignIn>}></Route>
            <Route path="/signup/:type" element={<SignUp></SignUp>}></Route>
            <Route path="/signup/:type" element={<SignUp></SignUp>}></Route>
            <Route path="/packagedetails/:id" element={<PackageDetails></PackageDetails>}></Route>
          </Route>
        </Routes>
      </HashRouter>
    </>
  );
}

export default App;
