import { Outlet } from "react-router-dom";
import Navbar from "../navbar/Navbar";
import "./LandingPage.css";
import AlertMessage from "../Shared/AlertMessage";
import Loader from "../Shared/Loader";
export default function LandingPage() {
  return (
    <>
    <AlertMessage></AlertMessage>
    <Loader></Loader>
    <Navbar></Navbar>
      <div className="main-container">
           <Outlet></Outlet>
      </div>
    </>
  );
}


