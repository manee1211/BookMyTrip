import { Link, useNavigate, useParams } from "react-router-dom";
import "./SignUp.css";
import "../../common.css";
import eyeIcon from "@iconify/icons-mdi/eye-outline";
import eyeOffIcon from "@iconify/icons-mdi/eye-off-outline";
import successIcon from "@iconify/icons-mdi/check-circle-outline";
import tickIcon from "@iconify/icons-mdi/check-circle";
import { Icon } from "@iconify/react/dist/iconify.js";
import { useState } from "react";
function SignUp() {
  const params = useParams();
  const navigate = useNavigate();
  const partnerType = params.type;
  const [passwordType, setPasswordType] = useState("password");
  const [showPassword, setShowPassword] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [passwordConfirmed, setPasswordConfirmed] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    contactNo: "",
    state: "",
    pinCode: "",
    address: "",
    userType: partnerType,
  });

  const handleNavigation = (link)=>{
    navigate(link);
  }

  const handleInput = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    if (name == "password" && (value != "" || form.confirmPassword != "")) {
      setPasswordConfirmed(value == form.confirmPassword);
    } else if (
      name == "confirmPassword" ||
      value != "" ||
      form.password != ""
    ) {
      setPasswordConfirmed(value == form.password);
    }
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const togglePasswordType = () => {
    setPasswordType(showPassword ? "password" : "text");
    setShowPassword((prev) => !prev);
  };

  const handleSignUp = ()=>{
    setShowSuccess(true);
  }

  return (
    <>
      <div className="page-container">
        <div className="signup-container">
          <div className="signup-card">
            {!showSuccess && (<div className="signup-section">
              <div className="signup-title">Sign Up</div>
              <div className="signin-form">
                <div className="field-row">
                  <div className="field-signup">
                    <input
                      name="name"
                      type="text"
                      placeholder="Full Name"
                      className="signup-input"
                      value={form.name}
                      onChange={(e) => handleInput(e)}
                    />
                  </div>
                  <div className="field-signup">
                    <input
                      name="email"
                      type="email"
                      placeholder="Email"
                      className="signup-input"
                      value={form.email}
                      onChange={(e) => handleInput(e)}
                    />
                  </div>
                </div>
                <div className="field-row">
                  <div className="field-signup">
                    <input
                      name="password"
                      type={passwordType}
                      placeholder="Password"
                      className="signup-input signup-password"
                      value={form.password}
                      onChange={(e) => handleInput(e)}
                    />
                    <Icon
                      className="signup-field-icon"
                      icon={showPassword ? eyeOffIcon : eyeIcon}
                      onClick={() => togglePasswordType()}
                    ></Icon>
                  </div>
                  <div className="field-signup">
                    <input
                      name="confirmPassword"
                      type="password"
                      placeholder="Confirm Password"
                      className="signup-input signup-password"
                      value={form.confirmPassword}
                      onChange={(e) => handleInput(e)}
                    />
                    {passwordConfirmed && (
                      <Icon
                        className="signup-field-icon success-icon"
                        icon={successIcon}
                      ></Icon>
                    )}
                  </div>
                </div>
                <div className="field-row">
                  <div className="field-signup">
                    <input
                      name="contactNo"
                      type="text"
                      placeholder="Mobile Number"
                      className="signup-input"
                      value={form.contactNo}
                      onChange={(e) => handleInput(e)}
                    />
                  </div>
                  <div className="field-signup">
                    <input
                      name="state"
                      type="text"
                      placeholder="State"
                      className="signup-input"
                      value={form.state}
                      onChange={(e) => handleInput(e)}
                    />
                  </div>
                </div>
                <div className="field-row">
                  <div className="field-signup">
                    <input
                      name="pinCode"
                      type="text"
                      placeholder="Pin Code"
                      className="signup-input"
                      value={form.pinCode}
                      onChange={(e) => handleInput(e)}
                    />
                  </div>
                  <div className="field-signup">
                    <input
                      name="address"
                      type="text"
                      placeholder="Address"
                      className="signup-input"
                      value={form.address}
                      onChange={(e) => handleInput(e)}
                    />
                  </div>
                </div>
              </div>
              <div className="signup-form-btn-section">
                <button className="signup-form-btn" onClick={()=>handleSignUp()}>Sign Up</button>
              </div>
              <div className="signin-form-link">
                <div className="signup-form-link-text">
                  Already have any account?
                </div>
                <Link className="link signin-link" to={"/signin"}>
                  Sign In
                </Link>
              </div>
            </div>)}
            {showSuccess&&(<div className="signup-success">
                <div className="signup-success-icon-row">
                    <Icon icon={tickIcon} className="signup-success-icon"></Icon>
                </div>
                <div className="signup-success-text-row">You are successfully Registered</div>
                <div className="signup-success-btn-row">
                <button className="signup-success-btn" onClick={()=>handleNavigation("/signin")} >Sign In</button>
                </div>
            </div>)}
          </div>
        </div>
      </div>
    </>
  );
}

export default SignUp;
