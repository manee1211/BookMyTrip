import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  id: "",
  name: "",
  email: "",
  userType: "",
};

const userSlice = createSlice({
  name: "user",
  initialState: initialState,
  reducers: {
    login(state, action) {
      state.id = action.payload.id;
      state.name = action.payload.name;
      state.email = action.payload.email;
      state.userType = action.payload.userType;
    },
    clear(state) {
      state.id = "";
      state.name = "";
      state.email = "";
      state.userType = "";
    },
  },
});

export const userActions = userSlice.actions;
export const userReducer = userSlice.reducer;
