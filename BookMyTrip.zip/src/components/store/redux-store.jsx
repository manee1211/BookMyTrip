import { combineReducers,configureStore } from "@reduxjs/toolkit";
import { alertReducer } from "./AlertStore";
import { loaderReducer } from "./LoaderStore";
import { userReducer } from "./userStore";
import { sessionReducer } from "./sessionStore";

import {
    persistStore,
    persistReducer,
    FLUSH,
    REHYDRATE,
    PAUSE,
    PERSIST,
    PURGE,
    REGISTER

} from 'redux-persist'

import storage from "redux-persist/lib/storage";
import session from "redux-persist/lib/storage/session";
import { version } from "react";

const reducers = combineReducers({loader:loaderReducer,alert:alertReducer,user:userReducer,session:sessionReducer});

const persistConfig = {
    key:'user',
    version:1,
    storage,
    whitelist:['user','session']
}

const persistedReducer = persistReducer(persistConfig,reducers);

const store = configureStore({
    reducer:persistedReducer,
    middleware:(getDefaultMiddleware)=>
        getDefaultMiddleware({
            serializableCheck:{
                ignoreActions:[FLUSH,REHYDRATE,PAUSE,PERSIST,PURGE,REGISTER]
            }
        })
});

export default store;
export const persistor = persistStore(store);