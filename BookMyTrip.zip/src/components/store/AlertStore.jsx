import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  alertState: false,
  message:'',
  type:''
};

const alertSlice = createSlice({
  name: "alert",
  initialState: initialState,
  reducers: {
    openAlert(state,action) {
      state.alertState = action.payload.alertState;
      state.message = action.payload.message;
      state.type = action.payload.type;
    },
    close(state) {
        state.alertState = '';
        state.message = '';
        state.type = '';
    },
  },
});

export const alertActions = alertSlice.actions;
export const alertReducer = alertSlice.reducer;
