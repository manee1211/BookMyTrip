import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  token: "",
};

const sessionSlice = createSlice({
  name: "session",
  initialState: initialState,
  reducers: {
    login(state, action) {
      state.token = action.payload.token;
    },
    clear(state) {
      state.token = "";
    },
  },
});

export const sessionActions = sessionSlice.actions;
export const sessionReducer = sessionSlice.reducer;
