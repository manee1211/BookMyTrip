import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  isLoaderOn: false,
};

const loaderSlice = createSlice({
  name: "loader",
  initialState: initialState,
  reducers: {
    open(state) {
      state.isLoaderOn = true;
    },
    clear(state) {
      state.isLoaderOn = false;
    },
  },
});

export const loaderActions = loaderSlice.actions;
export const loaderReducer = loaderSlice.reducer;
