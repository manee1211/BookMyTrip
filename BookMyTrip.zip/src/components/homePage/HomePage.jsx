
import ImageSlider from "../imageSlider/ImageSlider";
import PackageList from "../packageList/PackageList";
import "./HomePage.css";

export default function HomePage() {
  const images = config.images;
  return (
    <>
    
      <div className="homepage-main">
        <ImageSlider images={images}></ImageSlider>
        <PackageList></PackageList>
      </div>
    </>
  );
}


