import "./SignIn.css";
import "../../common.css";
import { useState } from "react";
import eyeIcon from "@iconify/icons-mdi/eye-outline";
import eyeOffIcon from "@iconify/icons-mdi/eye-off-outline";
import googleIcon from "@iconify/icons-mdi/google";
import { Icon } from "@iconify/react/dist/iconify.js";
import { Link } from "react-router-dom";
import googlePn from "/google.png";
function SignIn() {
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const [passwordType, setPasswordType] = useState("password");
  const [showPassword, setShowPassword] = useState(false);

  const handleInput = (e) => {
    if (e.target.name == "email") {
      setEmail(e.target.value);
    } else if (e.target.name == "password") {
      setPassword(e.target.value);
    }
  };

  const togglePasswordType = () => {
    setPasswordType(showPassword ? "password" : "text");
    setShowPassword((prev) => !prev);
  };

  return (
    <>
      <div className="page-container">
        <div className="signin-container">
          <div className="signin-card">
            <div className="signin-section">
              <div className="signin-title">Sign In</div>
              <div className="signin-form">
                <div className="field input-field">
                  <input
                    onChange={(e) => handleInput(e)}
                    type="email"
                    placeholder="Email"
                    className="input"
                    value={email}
                  />
                </div>

                <div className="field input-field">
                  <input
                    onChange={(e) => handleInput(e)}
                    type={passwordType}
                    placeholder="Password"
                    className="password"
                    value={password}
                  />
                  <Icon
                    className="input-field-icon"
                    icon={showPassword ? eyeOffIcon : eyeIcon}
                    onClick={() => togglePasswordType()}
                  ></Icon>
                </div>
              </div>
              <div className="signin-forget-password">
                <Link className="link forget-password-link" to={"#"}>
                  Forgot Password?
                </Link>
              </div>
              <div className="signin-form-btn-section">
                <button className="signin-form-btn">Sign In</button>
              </div>
              <div className="signup-form-link">
                <div className="signup-form-link-text">
                  Don't have an account?
                </div>
                <Link className="link signup-link" to={"/signup/individual"}>
                  Sign Up
                </Link>
              </div>
              <div className="or-line"></div>
              <div className="signin-socialmedia">
                <div className="signin-socialmedia-google">
                  <button className="signin-socialmedia-google-btn">
                    <span className="google-icon">
                      <img src={googlePn} alt="" class="google-image" />
                    </span>{" "}
                    <div className="socialmedia-btn-txt">
                      Sign In with Google
                    </div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default SignIn;
