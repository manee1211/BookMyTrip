import { Backdrop, CircularProgress } from "@mui/material";
import { useSelector } from "react-redux";

export default function Loader() {
  const { isLoaderOn } = useSelector((state) => state.loader);

  return (
    isLoaderOn && (
      <Backdrop
        sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={isLoaderOn}
      >
        <CircularProgress
          thickness={4}
          sx={{ color: "var(--loader-color)" }}
        ></CircularProgress>
      </Backdrop>
    )
  );
}
