import { useSelector } from "react-redux";
import { useCloseAlert } from "../functions/ReduxActions";
import { Alert, Snackbar } from "@mui/material";

import { Icon } from "@iconify/react/dist/iconify.js";
import tickIcon from "@iconify/icons-mdi/check-circle";
import errorIcon from "@iconify/icons-mdi/error";
function AlertMessage(){
    const closeAlert = useCloseAlert();
    const {alertState,message,type} = useSelector((state)=>state.alert);
    const alertAutoHideDuration = config.alertConfig.alertAutoHideDuration;
    const vertical = config.alertConfig.vertical;
    const horizontal = config.alertConfig.horizontal;
    const sxSnackBar = {
        'border-radius':'10px',
        "& .MuiAlert-root.MuiAlert-filledSuccess":{
            color:'var(--alert-font-color)',
            backgroundColor:"var(--alert-success-bg)",
            fontFamily:"var(--font-medium)"
        },
        "& .MuiAlert-root.MuiAlert-filledError":{
            color:'var(--alert-font-color)',
            backgroundColor:"var(--alert-error-bg)",
            fontFamily:"var(--font-medium)"
        }
    }

    const handleClose = ()=>{
        closeAlert();
    };

    return (
        alertState && (
            <>
            <Snackbar sx={sxSnackBar} anchorOrigin={{vertical,horizontal}} open={alertState} onClose={handleClose} autoHideDuration={alertAutoHideDuration}>
                <Alert
                    variant="filled"
                    onClose={handleClose}
                    severity={Severity[type]}
                    sx={[{width:"100%"}]}
                    iconMapping={{
                        success:(
                            <Icon icon={tickIcon} fontSize="inherit" sx={{color:"var(--alert-success-bg)"}}></Icon>
                        ),
                        error:<Icon icon={errorIcon} fontSize="inherit"></Icon>
                    }}
                >
                    {message?message:Message[type]}
                </Alert>
                
            </Snackbar>
            </>
        )
    );
}

export const Severity = {
    ERROR:"error",
    SUCCESS:"success"
}

const Message = {
    [Severity.ERROR] : "Error Message",
    [Severity.SUCCESS] : "Success Message"
}

export default AlertMessage;