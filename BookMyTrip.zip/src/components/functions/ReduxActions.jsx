import { useDispatch, useSelector } from "react-redux";
import { alertActions } from "../store/AlertStore";
import { loaderActions } from "../store/LoaderStore";
import { userActions } from "../store/userStore";
import { sessionActions } from "../store/sessionStore";

export const useShowAlertSuccess = () => {
  const dispatch = useDispatch();
  return (message) => {
    dispatch(
      alertActions.openAlert({
        alertState: true,
        message: message,
        type: "SUCCESS",
      })
    );
  };
};

export const useShowAlertError = () => {
  const dispatch = useDispatch();
  return (message) => {
    dispatch(
      alertActions.openAlert({
        alertState: true,
        message: message,
        type: "ERROR",
      })
    );
  };
};

export const useCloseAlert = () => {
  const dispatch = useDispatch();
  return () => {
    dispatch(alertActions.close());
  };
};

export const useShowLoading = () => {
  const dispatch = useDispatch();
  return () => {
    dispatch(loaderActions.open());
  };
};

export const useHideLoading = () => {
  const dispatch = useDispatch();
  return () => {
    dispatch(loaderActions.close());
  };
};

export const useLogin = () => {
  const dispatch = useDispatch();
  return (userData) => {
    dispatch(userActions.login(userData));
  };
};

export const useUserData = () =>{
    const userData = useSelector((state)=>state.user);
    return userData;
}

export const useSaveSession = () => {
    const dispatch = useDispatch();
    return (token) => {
      dispatch(sessionActions.save(token));
    };
  };

  export const useSessionClear = () => {
    const dispatch = useDispatch();
    return () => {
      dispatch(sessionActions.clear());
    };
  };

  export const useSession = () =>{
    const session = useSelector((state)=>state.session);
    return session?.token||'';
}