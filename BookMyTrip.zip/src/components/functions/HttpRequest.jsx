


const appUrl = config.backendURL;

export const getRequest = async (api,sessionToken) =>{
    try{
        const response = await axios.get(`${appUrl}${api}`,{
            headers:{
                Authorization:`Bearer ${sessionToken}`
            }
        })

        return response.data;
    }catch(error){
        console.log("error in get request:",error);
        if(error && error.response && error.response.data){
            return error.response.data;
        }
        throw error;
    }
}

export const postRequest = async (api,data,sessionToken) =>{
    try{
        const response = await axios.post(`${appUrl}${api}`,data,{
            headers:{
                Authorization:`Bearer ${sessionToken}`,
                "Content-Type":"application/json"
            }
        })

        return response.data;
    }catch(error){
        console.log("error in post request:",error);
        if(error && error.response && error.response.data){
            return error.response.data;
        }
        throw error;
    }
}

export const deleteRequest = async (api,data,sessionToken) =>{
    try{
        const response = await axios.delete(`${appUrl}${api}`,data,{
            headers:{
                Authorization:`Bearer ${sessionToken}`,
                "Content-Type":"application/json"
            }
        })

        return response.data;
    }catch(error){
        console.log("error in delete request:",error);
        if(error && error.response && error.response.data){
            return error.response.data;
        }
        throw error;
    }
}

export const putRequest = async (api,data,sessionToken) =>{
    try{
        const response = await axios.put(`${appUrl}${api}`,data,{
            headers:{
                Authorization:`Bearer ${sessionToken}`,
                "Content-Type":"application/json"
            }
        })

        return response.data;
    }catch(error){
        console.log("error in put request:",error);
        if(error && error.response && error.response.data){
            return error.response.data;
        }
        throw error;
    }
}

export const patchRequest = async (api,data,sessionToken) =>{
    try{
        const response = await axios.patch(`${appUrl}${api}`,data,{
            headers:{
                Authorization:`Bearer ${sessionToken}`,
                "Content-Type":"application/json"
            }
        })

        return response.data;
    }catch(error){
        console.log("error in patch request:",error);
        if(error && error.response && error.response.data){
            return error.response.data;
        }
        throw error;
    }
}

export const downloadFileById = async (api,fileName,sessionToken) =>{
    try{
        const response = await axios.get(`${appUrl}${api}`,{
            requestType:'blob',
            headers:{
                Authorization:`Bearer ${sessionToken}`
            }
        })
        if(response && response.status===200){
            const downloadUrl = window.URL.createObjectURL(new Blob([response.data]));
            let link = document.createElement('a');
            link.href = downloadUrl;
            link.setAttribute('download',fileName);
            document.body.append(link);
            link.click();
            link.remove();
        }
        return response.status;
    }catch(error){
        console.log("error in patch request:",error);
        if(error && error.response && error.response.data){
            return error.response.data;
        }
        throw error;
    }
}

export const commonUploadFile = async (api,formData,sessionToken) =>{
    try{
        const response = await axios.post(`${appUrl}${api}`,formData,{
            headers:{
                Authorization:`Bearer ${sessionToken}`,
                "Content-Type":"multipart/form-data"
            }
        })

        return response.data;
    }catch(error){
        console.log("error in patch request:",error);
        if(error && error.response && error.response.data){
            return error.response.data;
        }
        throw error;
    }
}