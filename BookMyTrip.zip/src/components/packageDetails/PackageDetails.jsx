import "./PackageDetails.css";
import "../../common.css";
import rightIcon from "@iconify/icons-mdi/chevron-right";
import leftIcon from "@iconify/icons-mdi/chevron-left";
import hyphenIcon from "@iconify/icons-mdi/horizontal-line";
import tickIcon from "@iconify/icons-mdi/tick";
import { Icon } from "@iconify/react/dist/iconify.js";
import { useState } from "react";
import Card from "@mui/material/Card";
import { CardContent, CardMedia } from "@mui/material";
import { useNavigate } from "react-router-dom";

import ImageList from "@mui/material/ImageList";
import ImageListItem from "@mui/material/ImageListItem";
export default function PackageDetails() {
  const navigate = useNavigate();
  const handleNavigation = (link) => {
    navigate(link);
  };

  const [packageDetails, setPackageDetails] = useState({
    id: 1,
    title: "Thrilling Manali & Shimla Holiday",
    destinations: [
      { city: "Shimla", days: 3 },
      { city: "Manali", days: 3 },
    ],
    days: 6,
    nights: 5,
    totalPrice: 21450,
    rating: 4.5,
    images: [
      "http://127.0.0.1:7100/images/gallary1.jpg",
      "http://127.0.0.1:7100/images/gallary2.jpg",
      "http://127.0.0.1:7100/images/gallary3.jpg",
      "http://127.0.0.1:7100/images/gallary4.jpg",
      "http://127.0.0.1:7100/images/gallary5.jpg",
    ],
    daywiseDetails: [
      {
        id: 1,
        title: "Shimla",
        itinerary: [
          {
            id: 1,
            title: "Chandigarh to Shimla",
            type: "travel",
            image: "http://127.0.0.1:7100/images/car.png",
            price: 1000,
            isRemove: true,
            rating: "3.5",
          },
          {
            id: 2,
            title: "Sightseeing in Shimla",
            description:
              "Approximately 90 kilometers away from Shimla, Pinjore Gardens, also known as Yadavindra Gardens, were laid out by Mughal Emperor Aurangzeb’s architect, Fidai Khan in the 17th century. Sprawling over an area of 100 acres, these terraced gardens are famous for an enchanting display of Mughal architecture and lawns with refreshing fountains. The bewitching beauty of these gardens attracts a majority of tourists, especially during the Pinjore Heritage Festival. There is a museum located nearby, displaying the history of Pinjore Gardens. Tourists can also visit Pinjore Gardens on their way to Shimla from Chandigarh and revel in the serenity amidst greenery. Car itineraries usually do not include an extended stop here, therefore keep a look out while you pass by this attraction.",
            type: "Sightseeing",
            image: "http://127.0.0.1:7100/images/itr1.jpg",
            places: ["Pinjore Gardens"],
            price: 500,
            isRemove: false,
            rating: "4.5",
          },
          {
            id: 3,
            title: "Check-in to Hotel in Kachi Ghatti",
            type: "hotel",
            image: "http://127.0.0.1:7100/images/itr2.jpg",
            price: 1500,
            isRemove: true,
            rating: "4.2",
          },
        ],
      },
      {
        id: 2,
        title: "Shimla",
        itinerary: [
          {
            id: 4,
            title: "Sightseeing in Shimla",
            description:
              "Located 16 kilometers from Shimla, Kufri is bestowed with slopes, which makes it a hub for adventure lovers. A great place to unwind, Kufri offers panoramic views of the Himalayas. This tiny tinsel town features various places of interest like Himalayan Nature Park, Chini Bungalow, Kufri Fun World, etc. The highest peak in Kufri - Mahasu Peak is yet another famous hotspot for tourists. Car services are available till the nearest point to Kufri. Also, the trek to Mahasu Peak requires a lot of walking, hence it is recommended to wear comfortable shoes. Also, pony services are available to reach the peak.",
            type: "Sightseeing",
            image: "http://127.0.0.1:7100/images/itr3.jpg",
            places: [
              "Kufri",
              "Mall road",
              "Shimla Church",
              "Scandal Point",
              "Gaiety Theatre",
              "Townhall",
            ],
            price: 2500,
            isRemove: false,
            rating: "4.8",
          },
        ],
      },
      {
        id: 3,
        title: "Shimla To Manali",
        itinerary: [
          {
            id: 5,
            title: "Shimla To Manali",
            type: "travel",
            image: "http://127.0.0.1:7100/images/car.png",
            price: 1000,
            isRemove: false,
            rating: "4.6",
          },
          {
            id: 6,
            title: "Check-in to Hotel in Aleo",
            type: "hotel",
            image: "http://127.0.0.1:7100/images/itr4.jpg",
            price: 2500,
            isRemove: false,
            rating: "4.1",
          },
        ],
      },
      {
        id: 4,
        title: "Manali",
        itinerary: [
          {
            id: 7,
            title: "Sightseeing in Manali",
            description:
              "Located in a small village called Vashisht, the Vashisht Kund is situated around 6 kms away from Manali. One of the oldest temples in Manali, it depicts intricate wooden carvings and traditional Indian-style architecture. The temple is named after sage Vashisht, one of the seven main sages of the Hindu religion. According to legends, sage Vashisht meditated here and vowed to start a new life after learning that his children were murdered by Vishwamitra. The temple is also famous for its hot water springs which are believed to have medicinal properties.",
            type: "Sightseeing",
            image: "http://127.0.0.1:7100/images/itr5.jpg",
            places: ["Vashisht Kund", "Hadimba Temple", "Tibetan Monastery"],
            price: 3500,
            isRemove: false,
            rating: "4.9",
          },
          {
            id: 8,
            title: "Photoshoot in Manali",
            description:
              "Capture memories of your holiday in Manali with a personal photoshoot. Pose against the quaint surroundings of the Hidimba Devi Temple as a professional photographer clicks beautiful pictures. Note: You must reach Hidimba Devi Temple on your own and meet your photographer. The activity is inclusive of 25 edited pictures and 1 photo collage.",
            type: "Photoshoot",
            image: "http://127.0.0.1:7100/images/itr6.jpg",
            places: ["Vashisht Kund", "Hadimba Temple", "Tibetan Monastery"],
            price: 3500,
            isRemove: false,
            rating: "4.9",
          },
        ],
      },
      {
        id: 5,
        title: "Manali",
        itinerary: [
          {
            id: 9,
            title: "Sightseeing in Manali",
            description:
              "Around 14 kilometers from the Manali city, between Beas Kund and Solang Village, lies the Solang Valley, renowned for its scenic beauty and known for hosting finest adventure activities like skiing, trekking, paragliding, skating, zorbing, and parachuting. Not just the adventure seekers, the valley is a delight for nature lovers as well. View of gorgeous Himalayan peaks from the valley further adds to its beauty. The famous Atal Bihari Vajpayee Institute of Mountaineering and Allied Sports is also based here. During winters, the valleys host the famous winter skiing festival.",
            type: "Sightseeing",
            image: "http://127.0.0.1:7100/images/itr7.jpg",
            places: ["Solang Valley"],
            price: 1500,
            isRemove: false,
            rating: "4.0",
          },
        ],
      },
      {
        id: 6,
        title: "Manali to Chandigarh",
        itinerary: [
          {
            id: 10,
            title: "Manali to Chandigarh",
            type: "travel",
            image: "http://127.0.0.1:7100/images/car.png",
            price: 2000,
            isRemove: true,
            rating: "4.3",
          },
        ],
      },
    ],
  });

  return (
    <>
      <div className="page-container">
        <div className="packagedetails-container">
          <div className="packagedetails-card">
            <div className="packagedetails-main-section">
              <div className="packagedetails-title-section">
                <div className="packagedetails-title">
                  {packageDetails.title}
                </div>
                <div className="packagedetails-basic-details">
                  <div className="packagedetails-duration">{`${packageDetails.nights}N/${packageDetails.days}D`}</div>
                  <div
                    className="packagedetails-rating"
                    title="Rating"
                  >{`${packageDetails.rating}/5`}</div>
                  <div className="packagedetails-destinations">
                    {packageDetails.destinations.map((dest, dIndex) => (
                      <>
                        <div className="packagedetails-destination">
                          {`${dest.days}D ${dest.city}`}
                        </div>
                      </>
                    ))}
                  </div>
                </div>
              </div>
              <div className="packagedetails-gallary-section">
                <div className="packagedetails-gallary-title">
                  Image Gallery
                </div>
                <div className="packagedetails-gallary">
                  <ImageList
                    sx={{ width: "100%", minHeight: '320px' }}
                    cols={3}
                    rowHeight={120}
                  >
                    {packageDetails.images.map((item) => (
                      <ImageListItem key={item}>
                        <img
                          srcSet={`${item}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
                          src={`${item}?w=164&h=164&fit=crop&auto=format`}
                          alt={packageDetails.title}
                          loading="lazy"
                        />
                      </ImageListItem>
                    ))}
                  </ImageList>
                </div>
              </div>
              <div className="packagedetails-itinerary-section">
                <div className="packagedetails-itinerary-days">
                  {packageDetails.daywiseDetails.map((item, index) => (
                    <>
                      <div className="packagedetails-itinerary-day">
                        <div className="packagedetails-itinerary-day-title">
                          {`Day ${index + 1} - ${item.title}`}
                        </div>
                        <div className="daywise-itinerary">
                          {item.itinerary.map((itinerary, itineraryIndex) => (
                            <>
                              <Card
                                sx={{
                                  width: "100%",
                                  display: "flex",
                                  minHeight: "150",
                                }}
                              >
                                <CardMedia
                                  sx={{
                                    width: "150px",
                                  }}
                                  image={itinerary.image}
                                  title={itinerary.title}
                                />
                                <CardContent sx={{ width: "80%" }}>
                                  <div className="itinerary-card-section">
                                    <div className="itinerary-card-details">
                                      <div className="itinerary-card-title">
                                        {itinerary.title}
                                      </div>
                                      <div className="itinerary-card-rating">{`${itinerary.rating}/5`}</div>
                                      {itinerary.description && (
                                        <div className="itinerary-card-description-section">
                                          <div className="itinerary-card-description">
                                            {itinerary.description.substring(
                                              0,
                                              100
                                            )}
                                          </div>
                                          <div
                                            className="view-more"
                                            onClick={() => {}}
                                          >
                                            {" "}
                                            View More
                                          </div>
                                        </div>
                                      )}
                                      {itinerary.places && (
                                        <ul className="itinerary-card-places">
                                          {itinerary.places.map(
                                            (place, pIndex) => (
                                              <li>{place}</li>
                                            )
                                          )}
                                        </ul>
                                      )}
                                    </div>
                                    {itinerary.isRemove && (
                                      <div className="itinerary-card-action">
                                        Remove
                                      </div>
                                    )}
                                  </div>
                                </CardContent>
                              </Card>
                            </>
                          ))}
                        </div>
                      </div>
                    </>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <div className="packagebook-card">
            <div className="packagebook-main-section">
              <div className="book-date">
                <div className="book-date-label">From</div>
                <div className="book-date-input">
                  <input type="date" placeholder="Start Date" />
                </div>
              </div>

              <div className="book-date">
                <div className="book-date-label">To</div>
                <div className="book-date-input">
                  <input type="date" placeholder="Start Date" />
                </div>
              </div>
              <div className="book-price">
                <div className="book-price-number">{`Rs.${packageDetails.totalPrice}`}</div>
                <div className="book-price-unit">/Person</div>
              </div>
              <div className="booking-btn-div">
                <button className="booking-btn" onClick={() => {}}>
                  Book Package
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
