import "./PackageList.css";
import "../../common.css";
import rightIcon from "@iconify/icons-mdi/chevron-right";
import leftIcon from "@iconify/icons-mdi/chevron-left";
import hyphenIcon from "@iconify/icons-mdi/horizontal-line";
import tickIcon from "@iconify/icons-mdi/tick";
import { Icon } from "@iconify/react/dist/iconify.js";
import { useState } from "react";
import Card from "@mui/material/Card";
import { CardContent, CardMedia } from "@mui/material";
import { useNavigate } from "react-router-dom";
export default function PackageList() {
  const navigate = useNavigate()
  const handleNavigation = (link)=>{
    navigate(link);
  }
  const [packageList, setPackageList] = useState([
    {
      id: 3,
      thumbnail: "http://127.0.0.1:7100/images/thumb2.jpg",
      title: "Romantic Weekend in Scenic Shimla from Delhi",
      destination: "Shimla",
      days: "4",
      nights: "3",
      sightseeing: [
        "Christ Church, Shri Baba Balak Nath Mandir, Monkey Point",
        "Sunset Point, Lower And Upper Mall Road",
      ],
      features: [
        "Car Transfers",
        "Star Homestay",
        "Selected Meals",
        "3 Activities",
      ],
      totalPrice: "12560",
      rating: "3.7",
    },
    {
      id: 1,
      thumbnail: "http://127.0.0.1:7100/images/thumb1.jpg",
      title: "Short Getaway to Kasauli- From Delhi",
      destination: "Kasauli",
      days: "3",
      nights: "2",
      sightseeing: [
        "Christ Church, Shri Baba Balak Nath Mandir, Monkey Point",
        "Sunset Point, Lower And Upper Mall Road",
      ],
      features: [
        "Flights",
        "Car Transfers",
        "3 Star Hotel",
        "Selected Meals",
        "1 Activity",
      ],
      totalPrice: "15500",
      rating: "4.2",
    },
    {
      id: 2,
      thumbnail: "http://127.0.0.1:7100/images/thumb5.jpg",
      title: "Enchanting Manali & Shimla Vacay - From Chandigarh",
      destination: "Manali,Shimla",
      days: "6",
      nights: "5",
      sightseeing: [
        "Tibetan Monastery, Mall road, Kufri",
        "Solang Valley, Hadimba Temple, Vashishth Kund",
        "Shimla Church, Scandal point, Gaeity Theatre",
      ],
      features: [
        "Car Transfers",
        "3 Star Hotel",
        "Selected Meals",
        "4 Activities",
      ],
      totalPrice: "14455",
      rating: "4.5",
    },
    {
      id: 4,
      thumbnail: "http://127.0.0.1:7100/images/thumb3.jpg",
      title: "Brilliant Homestay in Manali",
      destination: "Shimla",
      days: "4",
      nights: "3",
      sightseeing: [
        "Solang Valley, Hadimba Temple, Vashishth Kund",
        "Tibetan Monastery",
      ],
      features: [
        "Car Transfers",
        "4 Star Hotel",
        "Selected Meals",
        "2 Activities",
      ],
      totalPrice: "12560",
      rating: "3.7",
    },
    {
      id: 5,
      thumbnail: "http://127.0.0.1:7100/images/thumb4.jpg",
      title: "Fantastic Manali Getaway - Honeymoon Special",
      destination: "Manali",
      days: "4",
      nights: "3",
      sightseeing: [
        "Solang Valley, Hadimba Temple, Vashishth Kund",
        "Tibetan Monastery"
      ],
      features: [
        "Car Transfers",
        "4 Star Hotel",
        "Selected Meals",
        "3 Activities",
      ],
      totalPrice: "12455",
      rating: "4.8",
    },
    {
      id: 6,
      thumbnail: "http://127.0.0.1:7100/images/thumb6.jpg",
      title: "Scenic Unique Stay in Banjar",
      destination: "Banjar",
      days: "4",
      nights: "3",
      sightseeing: [
        "Tirthan Valley, Seroyul Lake, Jibhi Falls",
        "Great Himalayan National Park",
      ],
      features: [
        "Car Transfers",
        "3 Star Hotel",
        "Selected Meals",
        "3 Activities",
      ],
      totalPrice: "17560",
      rating: "4.0",
    },
  ]);

  return (
    <>
      <div className="page-container">
        <div className="packagelist-container">
          <div className="packagelist-card">
            <div className="packagelist-main-section">
              <div className="packagelist-filter-section">
                <div className="filter-heading">Filters</div>
                <div className="duration-filter filter-section">
                  <div className="duration-filter-heading filters-head">
                    Durations(in Days)
                  </div>
                  <div className="filter-list">
                    <div className="filter-list-item">
                      <div className="filter-list-item-checkbox">
                        <input type="checkbox" name="duration" value={"1_3"} />
                      </div>
                      <div className="filter-list-item-label">
                        <Icon icon={leftIcon}></Icon>3D
                      </div>
                    </div>
                    <div className="filter-list-item">
                      <div className="filter-list-item-checkbox">
                        <input type="checkbox" name="duration" value={"3_4"} />
                      </div>
                      <div className="filter-list-item-label">
                        3D <Icon icon={hyphenIcon}></Icon> 4D
                      </div>
                    </div>
                    <div className="filter-list-item">
                      <div className="filter-list-item-checkbox">
                        <input type="checkbox" name="duration" value={"4_6"} />
                      </div>
                      <div className="filter-list-item-label">
                        4D <Icon icon={hyphenIcon}></Icon> 6D
                      </div>
                    </div>
                    <div className="filter-list-item">
                      <div className="filter-list-item-checkbox">
                        <input type="checkbox" name="duration" value={"6_"} />
                      </div>
                      <div className="filter-list-item-label">
                        <Icon icon={rightIcon}></Icon>6D
                      </div>
                    </div>
                  </div>
                </div>
                <div className="travel-filter filter-section">
                  <div className="travel-filter-heading filters-head">
                    Travel Type
                  </div>
                  <div className="travel-filter-items">
                    <button className="travel-filter-item">With Flight</button>
                    <button className="travel-filter-item">
                      Without Flight
                    </button>
                  </div>
                </div>
                <div className="budget-filter filter-section">
                  <div className="budget-filter-heading filters-head">
                    Budget(per person)
                  </div>
                  <div className="filter-list">
                    <div className="filter-list-item">
                      <div className="filter-list-item-checkbox">
                        <input
                          type="checkbox"
                          name="duration"
                          value={"1_15000"}
                        />
                      </div>
                      <div className="filter-list-item-label">
                        <Icon icon={leftIcon}></Icon>Rs.15,000
                      </div>
                    </div>
                    <div className="filter-list-item">
                      <div className="filter-list-item-checkbox">
                        <input
                          type="checkbox"
                          name="duration"
                          value={"15000_25000"}
                        />
                      </div>
                      <div className="filter-list-item-label">
                        Rs.15,000 <Icon icon={hyphenIcon}></Icon> Rs.20,000
                      </div>
                    </div>
                    <div className="filter-list-item">
                      <div className="filter-list-item-checkbox">
                        <input
                          type="checkbox"
                          name="duration"
                          value={"20000_30000"}
                        />
                      </div>
                      <div className="filter-list-item-label">
                        Rs.20,000 <Icon icon={hyphenIcon}></Icon> Rs.30,000
                      </div>
                    </div>
                    <div className="filter-list-item">
                      <div className="filter-list-item-checkbox">
                        <input type="checkbox" name="duration" value={"6_"} />
                      </div>
                      <div className="filter-list-item-label">
                        <Icon icon={rightIcon}></Icon>Rs.30,000
                      </div>
                    </div>
                  </div>
                </div>
                <div className="cities-filter filter-section">
                  <div className="cities-filter-heading filters-head">
                    Cities
                  </div>
                  <div className="filter-list">
                    <div className="filter-list-item">
                      <div className="filter-list-item-checkbox">
                        <input
                          type="checkbox"
                          name="duration"
                          value={"Shimla"}
                        />
                      </div>
                      <div className="filter-list-item-label">Shimla</div>
                    </div>
                    <div className="filter-list-item">
                      <div className="filter-list-item-checkbox">
                        <input
                          type="checkbox"
                          name="duration"
                          value={"Manali"}
                        />
                      </div>
                      <div className="filter-list-item-label">Manali</div>
                    </div>
                    <div className="filter-list-item">
                      <div className="filter-list-item-checkbox">
                        <input
                          type="checkbox"
                          name="duration"
                          value={"Dharamshala"}
                        />
                      </div>
                      <div className="filter-list-item-label">Dharamshala</div>
                    </div>
                    <div className="filter-list-item">
                      <div className="filter-list-item-checkbox">
                        <input
                          type="checkbox"
                          name="duration"
                          value={"Chandigarh"}
                        />
                      </div>
                      <div className="filter-list-item-label">Chandigarh</div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="packagelist-listing-section">
                <div className="packagelist-listing-items">
                  {packageList.map((item, index) => (
                    <>
                      <div
                        className="packagelist-listing-item"
                        key={item.id}
                        onClick={() => {handleNavigation(`/packagedetails/${item.id}`)}}
                      >
                        <Card sx={{ width: "100%" }}>
                          <CardMedia
                            sx={{ height: 160 }}
                            image={item.thumbnail}
                            title={item.title}
                          />
                          <CardContent>
                            <div className="card-content">
                              <div className="card-title-row">
                                <div className="card-title">{item.title}</div>
                                <div className="card-duration">{`${item.nights}N/${item.days}D`}</div>
                              </div>
                              <ul className="card-features-list">
                                {item.features.map((feature, fIndex) => (
                                  <li>{feature}</li>
                                ))}
                              </ul>
                              <ul className="card-sightseeing-list">
                                {item.sightseeing.map((sightseeing, sIndex) => (
                                  <li>
                                    <Icon icon={tickIcon}></Icon>{" "}
                                    {`Visit to ${sightseeing}`}
                                  </li>
                                ))}
                              </ul>
                              <div className="card-price-section">
                                <div className="card-review">
                                  {`${item.rating}/5`}
                                </div>
                                <div className="card-price">
                                  <div className="price-number">{`Rs.${item.totalPrice}`}</div>
                                  <div className="price-unit">/Person</div>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
