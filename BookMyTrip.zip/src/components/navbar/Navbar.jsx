import "./Navbar.css";
import "../../common.css"
import logo from "/logo.svg";
import { Icon } from "@iconify/react";
import searchIcon from "@iconify/icons-mdi/search";
import menuIcon from "@iconify/icons-mdi/menu";
import closeIcon from "@iconify/icons-mdi/close";
import profileIcon from "@iconify/icons-mdi/user-circle-outline";
import partnerIcon from "@iconify/icons-mdi/partnership";
import helpIcon from "@iconify/icons-mdi/chat-help-outline";
import bookingIcon from "@iconify/icons-mdi/briefcase-check-outline";
import lockIcon from "@iconify/icons-mdi/lock-outline";
import rightIcon from "@iconify/icons-mdi/chevron-right";
import downIcon from "@iconify/icons-mdi/chevron-down";

import { Link, NavLink, useNavigate } from "react-router-dom";
import { useState } from "react";
function Navbar() {
  const navigate = useNavigate();
  const [searchText, setSearchText] = useState("");
  const [menuClicked, setMenuClicked] = useState(false);

  const handleNavigation = (link)=>{
    setMenuClicked(false);
    navigate(link);
  }
  const handleSearch = (e) => {
    setSearchText(e.target.value);
  };

  const handleMenuClick = () => {
    setMenuClicked((prev) => !prev);
  };

  return (
    <>
      {menuClicked && (
        <div className="side-menu-container">
          <div className="side-menu-empty"></div>
          <div className="side-menu">
            <div className="side-menu-header">
              {/* <div className="side-menu-header-label">Hello!</div> */}
              <div className="side-menu-header-label">Hello, Charanjeet</div>
              <div className="side-menu-close-icon">
                <Icon
                  onClick={() => handleMenuClick()}
                  style={{
                    color: "#3b4261b3",
                    fontSize: "24px",
                    cursor: "pointer",
                  }}
                  icon={closeIcon}
                ></Icon>
              </div>
            </div>

            {/* <div className="register-row">
              <div className="register-text">Sign Up for more!</div>
              <div className="register-btn">
                
                <button onClick={()=> handleNavigation('/signup/individual')} className="signup-btn">Sign Up</button>
              </div>
            </div> */}
            <div className="side-menu-items">
              <div className="menu-row ">
                <div className="menu-row-container">
                  <div className="menu-icon">
                    <Icon
                      style={{
                        color: "#666666",
                        fontSize: "18px",
                      }}
                      icon={bookingIcon}
                    ></Icon>
                  </div>
                  <div className="menu-text">
                    <div className="menu-text-heading">Your Bookings</div>
                    <div className="menu-text-sub-heading">
                      View all your booking & purchases
                    </div>
                  </div>
                  <div className="menu-suffix-icon">
                    <Icon
                      style={{
                        color: "#666666",
                        fontSize: "18px",
                      }}
                      icon={lockIcon}
                    ></Icon>
                  </div>
                </div>
              </div>
              <div className="menu-row ">
                <div className="menu-row-container">
                  <div className="menu-icon">
                    <Icon
                      style={{
                        color: "#666666",
                        fontSize: "18px",
                      }}
                      icon={profileIcon}
                    ></Icon>
                  </div>
                  <div className="menu-text">
                    <div className="menu-text-heading">Your Profile</div>
                    <div className="menu-text-sub-heading">
                      View or edit your profile details
                    </div>
                  </div>
                  <div className="menu-suffix-icon">
                    <Icon
                      style={{
                        color: "#666666",
                        fontSize: "18px",
                      }}
                      icon={lockIcon}
                    ></Icon>
                  </div>
                </div>
              </div>

              {/* <div className="menu-row">
                <div className="menu-row-container">
                  <div className="menu-icon">
                    <Icon
                      style={{
                        color: "#666666",
                        fontSize: "18px",
                      }}
                      icon={partnerIcon}
                    ></Icon>
                  </div>
                  <div className="menu-text" onClick={()=> handleNavigation('/signup/partner')}>
                    <div className="menu-text-heading">Become Partner</div>
                    <div className="menu-text-sub-heading">
                      Sign up as a partner to showcase your own travel packages
                    </div>
                  </div>
                  <div className="menu-suffix-icon">
                    <Icon
                      style={{
                        color: "#666666",
                        fontSize: "18px",
                      }}
                      icon={rightIcon}
                    ></Icon>
                  </div>
                </div>
              </div> */}
              <div className="menu-row">
                <div className="menu-row-container">
                  <div className="menu-icon">
                    <Icon
                      style={{
                        color: "#666666",
                        fontSize: "18px",
                      }}
                      icon={helpIcon}
                    ></Icon>
                  </div>
                  <div className="menu-text">
                    <div className="menu-text-heading">Help & Support</div>
                    <div className="menu-text-sub-heading">
                      Ask for help or raise your queries
                    </div>
                  </div>
                  <div className="menu-suffix-icon">
                    <Icon
                      style={{
                        color: "#666666",
                        fontSize: "18px",
                      }}
                      icon={rightIcon}
                    ></Icon>
                  </div>
                </div>
              </div>
            </div>
            <div className="logout-section">
            <button className="logout-btn">Logout</button>
            </div>
          </div>
        </div>
      )}
      <div className="navbar-section">
        <div className="navbar-subsection">
          <div className="navbar-main">
            <div className="navbar-logo">
              <img height="60px" src={logo}></img>
            </div>
            <div className="navbar-search">
              <div className="search-input">
                <div className="search-input-field">
                  <div className="search-icon">
                    <Icon style={{ color: "#777777" }} icon={searchIcon}></Icon>
                  </div>
                  <div className="search-input-txt">
                    <input
                      className="search-input-form"
                      type="text"
                      value={searchText}
                      onChange={(e) => handleSearch(e)}
                      placeholder="Search by destination or title"
                    ></input>
                  </div>
                </div>
              </div>
            </div>
            <div className="navbar-menu">
              <div className="navbar-menu-items">
                <NavLink
                  to={"/"}
                  className={({ isActive }) =>
                    isActive ? "navbar-menu-link active" : "navbar-menu-link"
                  }
                >
                  Home
                </NavLink>
              </div>
              <div className="navbar-menu-items">
                <NavLink
                  to={"/packages"}
                  className={({ isActive }) =>
                    isActive ? "navbar-menu-link active" : "navbar-menu-link"
                  }
                >
                  Packages
                </NavLink>
              </div>
              <div className="navbar-menu-items">
                <NavLink
                  to={"/contact"}
                  className={({ isActive }) =>
                    isActive ? "navbar-menu-link active" : "navbar-menu-link"
                  }
                >
                  Contact Us
                </NavLink>
              </div>
            </div>
            <div className="navbar-user-section">
              {/* <button  onClick={()=> handleNavigation('/signin')} className="main-btn signin-btn">Sign in</button>
              <Icon
                onClick={() => handleMenuClick()}
                style={{
                  color: "#3b4261b3",
                  fontSize: "24px",
                  cursor: "pointer",
                }}
                icon={menuIcon}
              ></Icon> */}
              <div onClick={() => handleMenuClick()} className="signin-user-info">
                <Icon
                  onClick={() => handleMenuClick()}
                  style={{
                    color: "#3b4261b3",
                    fontSize: "24px",
                    cursor: "pointer",
                  }}
                  icon={profileIcon}
                ></Icon>
                <div className="signin-user-name">Charanjeet Singh</div>
              </div>
              <Icon
                onClick={() => handleMenuClick()}
                style={{
                  color: "#3b4261b3",
                  fontSize: "24px",
                  cursor: "pointer",
                }}
                icon={downIcon}
              ></Icon>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Navbar;
